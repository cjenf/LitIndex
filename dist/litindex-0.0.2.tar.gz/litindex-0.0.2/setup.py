import setuptools

setuptools.setup(
    name = "Litindex",                                                                                                                              
    version = "0.0.2",
    author = "Cheng",
    license='MIT license',
    author_email="cjenf844747@gmail.com",
    description="Search for books and various information about books",
    url="https://github.com/cjenf/LitIndex", 
    python_requires='>=3.11.4'
)