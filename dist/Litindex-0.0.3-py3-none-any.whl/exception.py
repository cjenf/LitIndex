"""Exception module"""

class NotFoundError(Exception):
    pass